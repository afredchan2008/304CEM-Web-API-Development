module.exports={
    MongoURI:'mongodb+srv://website:123456Abc@cluster0-5iqck.mongodb.net/test?retryWrites=true'
}